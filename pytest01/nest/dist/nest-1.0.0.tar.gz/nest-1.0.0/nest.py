"""这是我写的第一个python的函数，使用递归，进行判断，输出列表中的每一项 """
def f(key,level):
    for each in key:
        if(isinstance(each,list)):
            f(each,level)
        else:
            for number in range(level):
                print('\t')
            print(each)


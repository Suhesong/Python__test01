from distutils.core import setup

setup(
    name='nest',
    version='1.0.0',
    py_modules=['nest'],
    author='suhesong',
    author_email='937445794@qq.com',
    url='www.xiaosu.xyz',
    description='a simple module',
)